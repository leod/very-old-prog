Ein typisches Jump'n'run ...

Autor: Leonard Dahlmann

Steuerung:

Pfeiltaste rechts: nach rechts laufen
Pfeiltaste links: nach links laufen
Control: springen (l�nger gedr�ckt halten = h�her springen)
Leertaste: beschleunigen (umso schneller man l�uft, desto h�her kann man springen)
Leertaste: schie�en (nur wenn man das powerup hat)
Enter: pause
Tab+Enter: beenden

Danke an Snake und AndyX f�rs Testen.
